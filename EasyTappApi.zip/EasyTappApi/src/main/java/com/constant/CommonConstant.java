package com.constant;

public class CommonConstant {

	private CommonConstant() {
		
	}
	
	public static final Long VCODE_VALID_TS=new Long("5");
}
