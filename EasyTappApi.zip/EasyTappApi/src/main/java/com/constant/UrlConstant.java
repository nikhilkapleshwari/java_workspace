package com.constant;

public class UrlConstant {

	private UrlConstant() {

	}

	public static final String VERIFY_ACCOUNT = "http://139.59.59.19:3001/verifyAccount";
	public static final String SEND_FORGOT_PWD_MAIL = "http://139.59.59.19:3001/sendForgotPwdMail";

}
