package com.constant;

public class UrlConstant {

	private UrlConstant() {
		
	}
	
	public static final String VERIFY_ACCOUNT="http://localhost:3001/verifyAccount";
}
